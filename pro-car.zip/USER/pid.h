#include "sys.h"
#include "usart.h"
void pid_DeInit(float a,float b);
void start_pid(float processValue);
void start_pid_1(float processValue);
void pid_DeInit_1(float a,float b);
