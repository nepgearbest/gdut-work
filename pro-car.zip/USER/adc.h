
#include "sys.h"

void adc_init();
extern u32 adc_value[3];